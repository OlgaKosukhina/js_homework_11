const data = `[
    {
        "productItem": "ELLERY X M'O CAPSULE",
        "productDescription": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "Price": "$52.00",
        "productImage": "img/woman_1.svg",
        "productImageAlt": "woman_black_suit"
    },
    {
        "productItem": "ELLERY X M'O CAPSULE",
        "productDescription": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "Price": "$52.00",
        "productImage": "img/boy_1.png",
        "productImageAlt": "man_blue_sweetshirt"
    },
    {
        "productItem": "ELLERY X M'O CAPSULE",
        "productDescription": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "Price": "$52.00",
        "productImage": "img/man_2.png",
        "productImageAlt": "man_yellow_pants"
    },
    {
        "productItem": "ELLERY X M'O CAPSULE",
        "productDescription": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "Price": "$52.00",
        "productImage": "img/woman_2.png",
        "productImageAlt": "woman_blue_jacket"
    },
    {
        "productItem": "ELLERY X M'O CAPSULE",
        "productDescription": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "Price": "$52.00",
        "productImage": "img/woman_3.png",
        "productImageAlt": "woman_green_shirt"
    }
]`